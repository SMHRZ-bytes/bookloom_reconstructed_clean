import { withAuth } from 'next-auth/middleware'
import { NextResponse } from 'next/server'

export default withAuth(
  function middleware(req) {
    const token = req.nextauth.token
    const isAuthPage = req.nextUrl.pathname.startsWith('/auth')
    const isApiAuthRoute = req.nextUrl.pathname.startsWith('/api/auth')
    const isPublicApiRoute = req.nextUrl.pathname.startsWith('/api/public')

    // Redirect authenticated users away from auth pages
    if (token && isAuthPage && !isApiAuthRoute) {
      return NextResponse.redirect(new URL('/dashboard', req.url))
    }

    // Protect admin routes
    if (req.nextUrl.pathname.startsWith('/admin') && token?.role !== 'ADMIN') {
      return NextResponse.redirect(new URL('/dashboard', req.url))
    }

    // Protect editor routes
    if (
      req.nextUrl.pathname.startsWith('/editor') &&
      token?.role !== 'EDITOR' &&
      token?.role !== 'ADMIN'
    ) {
      return NextResponse.redirect(new URL('/dashboard', req.url))
    }

    return NextResponse.next()
  },
  {
    callbacks: {
      authorized: ({ token, req }) => {
        const isAuthPage = req.nextUrl.pathname.startsWith('/auth')
        const isPublicRoute =
          req.nextUrl.pathname === '/' ||
          req.nextUrl.pathname.startsWith('/api/public') ||
          req.nextUrl.pathname.startsWith('/_next') ||
          req.nextUrl.pathname.startsWith('/favicon')

        // Allow access to public routes
        if (isPublicRoute || isAuthPage) {
          return true
        }

        // Require auth for protected routes
        return !!token
      },
    },
  }
)

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - api/auth (NextAuth routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    '/((?!api/auth|_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}



