import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/router'
import { motion } from 'framer-motion'
import Link from 'next/link'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const router = useRouter()

  async function handleSubmit(e) {
    e.preventDefault()
    setError(null)
    const res = await signIn('credentials', { redirect: false, email, password })
    if (res.ok) router.push('/dashboard')
    else setError(res.error || 'Login failed')
  }

  return (
    <main className='min-h-screen flex items-center justify-center p-6'>
      <motion.form onSubmit={handleSubmit} initial={{opacity:0, y:10}} animate={{opacity:1,y:0}} transition={{duration:0.4}} className='w-full max-w-md bg-white dark:bg-gray-800 rounded-xl p-8 shadow'>
        <h2 className='text-2xl font-semibold mb-4'>Sign in</h2>
        {router.query.registered && <div className='mb-3 text-sm text-green-600'>Account created — please sign in.</div>}
        {error && <div className='mb-3 text-sm text-red-600'>{error}</div>}
        <label className='block mb-2'>Email
          <input required value={email} onChange={e=>setEmail(e.target.value)} className='mt-1 w-full rounded px-3 py-2 border' />
        </label>
        <label className='block mb-4'>Password
          <input required type='password' value={password} onChange={e=>setPassword(e.target.value)} className='mt-1 w-full rounded px-3 py-2 border' />
        </label>
        <button className='w-full py-2 rounded-lg bg-indigo-600 text-white'>Sign in</button>
        <p className='mt-4 text-sm'>No account? <Link href='/auth/signup'><a className='text-indigo-600'>Create one</a></Link></p>
      </motion.form>
    </main>
  )
}
