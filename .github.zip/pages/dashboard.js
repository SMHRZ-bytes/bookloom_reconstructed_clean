import { getSession, useSession, signOut } from 'next-auth/react'
import { motion } from 'framer-motion'

export default function Dashboard() {
  const { data: session } = useSession()
  return (
    <main className='min-h-screen p-8'>
      <motion.div initial={{opacity:0}} animate={{opacity:1}} className='max-w-3xl mx-auto bg-white dark:bg-gray-800 rounded-xl p-8 shadow'>
        <div className='flex justify-between items-center mb-6'>
          <h1 className='text-2xl font-bold'>Welcome{session?.user?.name ? `, ${session.user.name}` : ''}!</h1>
          <div className='text-sm text-gray-500'>{session?.user?.email}</div>
        </div>
        <p className='text-gray-600 dark:text-gray-300 mb-4'>This is your dashboard. Add features like projects, collaborative editing, AI tools, etc.</p>
        <button onClick={()=>signOut()} className='px-4 py-2 rounded bg-red-500 text-white'>Sign out</button>
      </motion.div>
    </main>
  )
}

export async function getServerSideProps(ctx) {
  const session = await getSession(ctx)
  if (!session) {
    return { redirect: { destination: '/auth/login', permanent: false } }
  }
  return { props: {} }
}
